question_lib_path = '../question_library/'
question_list = [
#	(mark, 	count, [directories])
	(4,	1,	['min_io_forward_*']),
	(4,	1,	['min_bull_[1-2]','min_bull_4']),
]
practice_mode = True
standalone = False
logged = False
log_dir = ''
