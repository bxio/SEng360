product_family = 'code_activator'
question_type = 'input_output'
hotspot_declarations = {'$y': 'int'}
display = r'''#include &lt;stdio.h>

int k = 0;
void bubble_sort(int a[], int n)
{
	int i,j,x;

	for (i = 0; i < n-1; i++) {
		for (j = n-1; j > i; j--) {
			if (a[j] < a[j-1]) {
				x = a[j]; a[j] = a[j-1]; a[j-1] = x;
				k++;
			}
		}
	} 
}
int main(int argc, char* argv[])
{
	int a[] = {3,1,2};
	bubble_sort(a,3);        
	printf("%i\n",k);

	return 0;
}
'''
argvs = r''''''
stdin = r''''''
stdout = r'''$y
'''
