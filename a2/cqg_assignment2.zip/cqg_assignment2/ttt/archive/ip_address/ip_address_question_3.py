tuples = ('ip_address_question_3','samenetworkornot','126','1','0','1','127','1','0','1')
