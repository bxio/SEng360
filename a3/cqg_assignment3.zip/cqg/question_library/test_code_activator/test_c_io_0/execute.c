int ca_argv_1;
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
ca_argv_1 = atoi(argv[argc-1+0]);
	int argvs,stdin,code = ca_argv_1,sum;
	argvs = atoi(argv[2]);
	scanf("stdin: %d",&stdin);
	sum = code+argvs+stdin;
	printf("stdout: %d\n", sum);
	return 0;
}
