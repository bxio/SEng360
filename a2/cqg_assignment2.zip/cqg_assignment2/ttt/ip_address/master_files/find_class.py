# 5 forward, 5 mixed
tuples = ('find_class_0','whichnetworkclass', '8','8','8','8')
tuples = ('find_class_1','whichnetworkclass', '128','1','1','8')
tuples = ('find_class_2','whichnetworkclass', '127','1','0','8')
tuples = ('find_class_3','whichnetworkclass', '202','13','172','9')
tuples = ('find_class_4','whichnetworkclass', '212','131','1','9')

tuples = ('find_class_5','whichnetworkclass', '9','$8','$8','$8')
tuples = ('find_class_6','whichnetworkclass', '121','$1','$1','$8')
tuples = ('find_class_7','whichnetworkclass', '127','$1','$0','8')
tuples = ('find_class_8','whichnetworkclass', '192','$13','$172','$9')
tuples = ('find_class_9','whichnetworkclass', '212','$131','1','9')
