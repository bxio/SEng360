game_type = 'Input/output'
parameter_types = {'stdin': {'$i1': 'int', '$i2': 'int'}, 'stdout': {'$y0': 'int'}}
