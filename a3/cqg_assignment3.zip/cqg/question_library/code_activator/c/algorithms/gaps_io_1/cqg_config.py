product_family = 'code_activator'
question_type = 'input_output'
hotspot_declarations = {'$y4': 'string', '$y0': 'string', '$y1': 'string', '$y2': 'string', '$y3': 'string'}
display = r'''#include &lt;stdio.h>

int x = 0;

void gaps(int x[],int n)
{
	int i=0, j=0;
	while (i < n) {
		if (j < x[i]) {
			printf("%d\n",j);
		} else {
			i++;
		}
		j++;
	}
}
int main(int argc, char* argv[])
{
	int a[] = {1};

	gaps(a,1);        

	return 0;
}
'''
argvs = r''''''
stdin = r''''''
stdout = r'''$y0
$y1
$y2
$y3
$y4
'''
