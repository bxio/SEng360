product_family = 'code_activator'
question_type = 'input_output'
hotspot_declarations = {'$y0': 'string'}
display = r'''#include &lt;stdio.h>
#include &lt;stdlib.h>

int main(int argc, char* argv[])
{
	int k; 
	for (k=1; k<=5; k++) { 
		printf("%d ", k); 
	} /*for*/ 
	return EXIT_SUCCESS; 
	return 0;
}
'''
argvs = r''''''
stdin = r''''''
stdout = r'''$y0
'''
