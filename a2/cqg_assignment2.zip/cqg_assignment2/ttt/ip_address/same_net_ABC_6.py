tuples = ('same_net_ABC_6','samenetworkornot', '192','$168','0','9', '192','$168','0','2')
