tuples = ('find_class_4','whichnetworkclass', '212','131','1','9')
