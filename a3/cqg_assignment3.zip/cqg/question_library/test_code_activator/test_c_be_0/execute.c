int ca_argv_1;
int ca_targets[1] = {0};
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
ca_argv_1 = atoi(argv[argc-1+0]);
	int argvs,stdin,code = ca_argv_1,sum;
	argvs = atoi(argv[2]);
	scanf("stdin: %d",&stdin);
	sum = code+argvs+stdin;
	if (sum <= 6) {
		ca_targets[0] = 1;
		printf("%d\n", sum);
	}
if (ca_targets[0])
	return 0;
else
	return 1;
	return 0;
}
