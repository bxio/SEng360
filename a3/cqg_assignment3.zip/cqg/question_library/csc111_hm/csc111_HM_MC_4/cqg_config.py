product_family = 'multiple_choice'
question_type = 'multiple_choice'

question_text = r'''Who developed the programming language C in 1972?'''
answers = ['a. Brian Kernighan ', 'b. James Gosling ', 'c. Dennis Ritchie ', 'd. Niklaus Wirth ']
correct_answer = 2
