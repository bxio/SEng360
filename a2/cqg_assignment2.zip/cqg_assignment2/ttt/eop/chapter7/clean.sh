q=../../../question_library/eop/chapter7/

rm -rf $q/*
