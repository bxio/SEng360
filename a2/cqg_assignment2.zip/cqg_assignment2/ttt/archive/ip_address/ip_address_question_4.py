tuples = ('ip_address_question_4','whichnetworkclass','126','1','0','1')
