game_type = 'Find the failure'
parameter_types = {'code': {'$x2': 'int', '$x1': 'int'}}
