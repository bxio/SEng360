question_list = [
#	(mark, 	count, [directories])
	(1,	4,	['py_while_continue_io_*']),
	(1,	4,	['py_range_advanced_io_*']),
	(1,	4,	['py_list_indexing_io_*']),
	(1,	2,	['py_shift_easy_*']),
	(1,	2,	['py_shift_hard*']),
	(1,	2,	['py_dictionary_forward*']),
#	(1,	2,	['py_dictionary_backward*']),
]

practice_mode = False
standalone = False
logged = False
log_dir = '../quiz_log/lab5'
