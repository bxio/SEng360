product_family = 'multiple_choice'
question_type = 'multiple_choice'

question_text = r'''What is the name of the function that should be present in every standard C program?'''
answers = ['a. stdio.h ', 'b. main ', 'c. printf ', 'd. begin']
correct_answer = 1
