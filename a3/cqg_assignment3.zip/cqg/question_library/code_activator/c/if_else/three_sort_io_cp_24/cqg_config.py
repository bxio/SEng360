product_family = 'code_activator'
question_type = 'input_output'
hotspot_declarations = {'$y0': 'int', '$y1': 'int', '$y2': 'int'}
display = r'''#include &lt;stdio.h>

int main(int argc, char* argv[])
{
	int a,b,c,x;

	a = 5;
	b = 7;
	c = 5;

	if (a > b) {
		x = a; a = b; b = x;
	}
	if (b > c) {
		x = b; b = c; c = x;
	}
	if (a > b) {
		x = a; a = b; b = x;
	}

	printf("%d %d %d\n",a,b,c);
	return 0;
}
'''
argvs = r''''''
stdin = r''''''
stdout = r'''$y0 $y1 $y2
'''
