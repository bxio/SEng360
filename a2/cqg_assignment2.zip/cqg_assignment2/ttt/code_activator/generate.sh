echo tutorial/c -------------------------------------------
cd tutorial/c
. generate.sh
cd ../..

# NEEDS WORK: templates out of date
#echo tutorial/java -------------------------------------------
#cd tutorial/java
#. generate.sh
#cd ../..

echo tutorial/python -------------------------------------------
cd tutorial/python
. generate.sh
cd ../..
