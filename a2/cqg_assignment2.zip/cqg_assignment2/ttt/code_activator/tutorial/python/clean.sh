q=../../../../question_library/code_activator/tutorial/python

rm -rf $q/*
