tuples = [0,1,2]
