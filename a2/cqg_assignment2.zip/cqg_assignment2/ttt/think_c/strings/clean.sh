q=../../../question_library/think_c/strings/

rm -rf $q/*
