product_family = 'multiple_choice'
question_type = 'multiple_choice'

question_text = r'''Which of the following is syntactically comment correct in the programming language C?'''
answers = ['a. /* Comment /*', 'b. ** Comment **', 'c. { Comments }', 'd. /* Comment */']
correct_answer = 3
