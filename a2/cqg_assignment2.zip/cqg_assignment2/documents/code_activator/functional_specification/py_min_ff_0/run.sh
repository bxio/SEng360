#!/bin/sh
python execute $@
