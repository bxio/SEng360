Each template in the parent directory is one line from one of these files.
