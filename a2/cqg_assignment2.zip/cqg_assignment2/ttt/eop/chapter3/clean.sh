q=../../../question_library/eop/chapter3/

rm -rf $q/*
