q=../../../../question_library/code_activator/tutorial/c

rm -rf $q/*
