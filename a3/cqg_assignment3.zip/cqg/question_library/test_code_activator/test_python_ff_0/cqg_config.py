product_family = 'code_activator'
question_type = 'find_the_failure'
hotspot_declarations = {'$stdin': 'int', '$code': 'int', '$argvs': 'int'}
display = r'''import sys

code = $code
argvs = int(sys.argv[2])
tokens = sys.stdin.read().split()
stdin = int(tokens[1])
sum = code+argvs+stdin
// print message only if sum is 6
if sum < 6:
	print "hello"
'''
argvs = r'''argvs: $argvs'''
stdin = r'''stdin: $stdin'''
stdout = r''''''
