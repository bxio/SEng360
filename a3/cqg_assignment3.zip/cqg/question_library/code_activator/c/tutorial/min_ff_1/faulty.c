#include <stdlib.h>

int ca_argv_1;
int ca_argv_2;
#include <stdio.h>

int main(int argc, char* argv[])
{
ca_argv_1 = atoi(argv[argc-2+0]);
ca_argv_2 = atoi(argv[argc-2+1]);
	int a,b;
	a = ca_argv_1;
	b = ca_argv_2;
	if (a < b)
		printf("%d\n", a);
	else
		printf("%d\n", a);
	return 0;
}
