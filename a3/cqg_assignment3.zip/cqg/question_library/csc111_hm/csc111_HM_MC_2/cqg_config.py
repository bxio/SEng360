product_family = 'multiple_choice'
question_type = 'multiple_choice'

question_text = r'''C programs are translated into object code using'''
answers = ['a. an editor ', 'b. a compiler ', 'c. an operating system ', 'd. a linker or builder ']
correct_answer = 1
