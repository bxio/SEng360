tuples = ('find_class_8','whichnetworkclass', '192','$13','$172','$9')
