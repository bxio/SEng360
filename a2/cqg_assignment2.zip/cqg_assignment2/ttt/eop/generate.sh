echo chapter2 -------------------------------------------
cd chapter2
. generate.sh
cd ..

echo chapter3 -------------------------------------------
cd chapter3
. generate.sh
cd ..

echo chapter7 -------------------------------------------
cd chapter7
. generate.sh
cd ..
