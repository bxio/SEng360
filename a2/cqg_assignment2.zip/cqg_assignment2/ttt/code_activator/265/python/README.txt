All templates upgraded/moved to templates/code_activator/python/
