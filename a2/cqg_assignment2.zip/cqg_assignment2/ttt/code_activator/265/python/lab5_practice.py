question_list = [
#	(mark, 	count, [directories])
# (marked quiz uses same questions)
	(1,	4,	['py_for_break_io_*']),
	(1,	4,	['py_while_continue_io_*']),
	(1,	4,	['py_min3_bull_*']),
	(1,	4,	['py_range_advanced_io_*']),
	(1,	4,	['py_list_indexing_io_*']),
]

practice_mode = True
standalone = False
logged = False
log_dir = ''
