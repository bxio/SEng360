tuples = ('ip_address_question_0','samenetworkornot','$x1','$x2','$x3','$x4','$y1','$y2','$y3','$y4')
