q=../../../question_library/eop/chapter2/

rm -rf $q/*

code_activator_generate.py hello_world_io.py $q
