tuples = ('find_class_0','whichnetworkclass', '8','8','8','8')
