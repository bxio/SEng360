product_family = 'multiple_choice'
question_type = 'multiple_choice'

question_text = r'''<tt>Question text</tt>which wraps question question question question questionquestion question question question question question'''
answers = ['Answer text which wraps answer answer answeranswer answer answer answer answer answer answer', 'answer 1', 'answer 2', 'answer 3']
correct_answer = [2, 3]
