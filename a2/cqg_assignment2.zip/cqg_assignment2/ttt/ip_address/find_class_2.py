tuples = ('find_class_2','whichnetworkclass', '127','1','0','8')
