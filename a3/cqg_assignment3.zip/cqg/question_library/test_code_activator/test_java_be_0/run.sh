#!/bin/sh
java Test $@