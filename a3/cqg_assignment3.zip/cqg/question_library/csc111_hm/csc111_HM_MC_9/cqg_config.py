product_family = 'multiple_choice'
question_type = 'multiple_choice'

question_text = r'''What is Eclipse? Check the most appropriate answer.'''
answers = ['a. A programming environment for the programming language C. ', 'b. A software development environment for the programming language Java. ', 'c. An editing, compiling, debugging, building and execution software development environment for different programming languages. ', 'd. None of the above ']
correct_answer = 2
