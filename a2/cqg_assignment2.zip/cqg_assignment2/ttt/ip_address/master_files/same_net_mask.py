# 6 forward, 4 mixed
tuples = ('same_net_mask_0','samesubnetornot', '126','1','0','10', '126','1','0','11', '255','255','255','240')
tuples = ('same_net_mask_1','samesubnetornot', '192','168','5','1', '192','168','5','16', '255','255','255','240')
tuples = ('same_net_mask_2','samesubnetornot', '192','168','5','1', '192','168','5','16', '255','255','255','224')
tuples = ('same_net_mask_3','samesubnetornot', '126','1','0','10', '126','127','0','1', '255','128','0','0')
tuples = ('same_net_mask_4','samesubnetornot', '126','1','0','10', '127','126','0','1', '255','128','0','0')
tuples = ('same_net_mask_5','samesubnetornot', '172','16','0','1', '172','1','0','11', '255','255','0','0')

tuples = ('same_net_mask_6','samesubnetornot', '126','$1','$0','$10', '126','$1','$0','$11', '255','255','255','240')
tuples = ('same_net_mask_7','samesubnetornot', '192','168','$5','1', '192','$168','5','$16', '255','255','255','$0')
tuples = ('same_net_mask_8','samesubnetornot', '192','168','5','66', '192','168','5','$65', '255','255','255','252')
tuples = ('same_net_mask_9','samesubnetornot', '173','16','0','1', '173','$16','$0','$1', '$255','$255','$0','$0')
