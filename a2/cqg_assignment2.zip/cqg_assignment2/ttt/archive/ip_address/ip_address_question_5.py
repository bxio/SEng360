tuples = ('ip_address_question_5','samesubnetornot','126','1','0','10','126','1','0','11','255','255','255','240')
