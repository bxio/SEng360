q=../../../question_library/think_c/pointers_arrays

rm -rf $q/*

# ***** functions
code_activator_generate.py linear_search_io.py $q
code_activator_generate.py linear_search_slices.py $q
