product_family = 'code_activator'
question_type = 'find_the_failure'
hotspot_declarations = {'$stdout': 'int', '$stdin': 'int', '$code': 'int', '$argvs': 'int'}
display = r'''#include &lt;stdio.h>
#include &lt;stdlib.h>

int main(int argc, char* argv[])
{
	int argvs,stdin,code = $code,sum;
	argvs = atoi(argv[2]);
	scanf("stdin: %d",&stdin);
	sum = code+argvs+stdin;
	// print message only if sum is 6
	if (sum < 6)
		printf("hello");
	return 0;
}
'''
argvs = r'''argvs: $argvs'''
stdin = r'''stdin: $stdin'''
stdout = r''''''
