ascii_string ca_argv_1;
#include <stdio.h>

int main(int argc, char* argv[])
{
ca_argv_1 = argv[argc-1+0];
	printf("%s\n",ca_argv_1);
	return 0;
}
