import sys

ca_argv_1 = 0
ca_targets = [0] * 1
import sys

ca_argv_1 = int(sys.argv[len(sys.argv)-1+0])
code = ca_argv_1
argvs = int(sys.argv[2])
tokens = sys.stdin.read().split()
stdin = int(tokens[1])
sum = code+argvs+stdin
if sum <= 6:
	ca_targets[0] = 1
	print "%d\n" % sum
if ca_targets[0] :
	sys.exit(0)
else:
	sys.exit(1)
