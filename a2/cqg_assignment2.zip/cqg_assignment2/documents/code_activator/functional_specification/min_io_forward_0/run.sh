#!/bin/sh
./execute $@