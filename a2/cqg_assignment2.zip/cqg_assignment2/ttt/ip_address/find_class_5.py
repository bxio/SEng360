tuples = ('find_class_5','whichnetworkclass', '9','$8','$8','$8')
