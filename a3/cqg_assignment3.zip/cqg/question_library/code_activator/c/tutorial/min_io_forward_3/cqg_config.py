product_family = 'code_activator'
question_type = 'input_output'
hotspot_declarations = {'$y0': 'int'}
display = r'''#include &lt;stdio.h>

int main(int argc, char* argv[])
{
	int a,b;
	a = 0;
	b = 3;
	if (a < b)
		printf("%d\n", a);
	else
		printf("%d\n", b);
	return 0;
}
'''
argvs = r''''''
stdin = r''''''
stdout = r'''$y0
'''
