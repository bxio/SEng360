product_family = 'code_activator'
question_type = 'input_output'
hotspot_declarations = {'$y0': 'float', '$y2': 'float'}
display = r'''#include &lt;stdio.h>

int main(int argc, char* argv[])
{
	int r,i;
	double x;

	r = 6;
	x = 1.0;
	for (i = 0; i < 3; i++) {
		x = (x + r/x) / 2;
		printf("%4.3f\n",x);
	}

	return 0;
}
'''
argvs = r''''''
stdin = r''''''
stdout = r'''$y0
2.607
$y2
'''
