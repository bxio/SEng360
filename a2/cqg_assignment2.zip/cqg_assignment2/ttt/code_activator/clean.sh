echo tutorial/c -------------------------------------------
cd tutorial/c
. clean.sh
cd ../..

echo tutorial/java -------------------------------------------
cd tutorial/java
. clean.sh
cd ../..

echo tutorial/python -------------------------------------------
cd tutorial/python
. clean.sh
cd ../..
