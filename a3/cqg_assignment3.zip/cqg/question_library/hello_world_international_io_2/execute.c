#include <stdio.h>

int main(int argc, char* argv[])
{
	printf("%s\n","hallo verden");
	return 0;
}
