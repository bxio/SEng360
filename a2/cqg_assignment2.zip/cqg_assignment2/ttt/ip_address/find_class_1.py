tuples = ('find_class_1','whichnetworkclass', '128','1','1','8')
