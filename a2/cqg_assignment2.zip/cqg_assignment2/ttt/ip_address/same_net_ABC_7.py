tuples = ('same_net_ABC_7','samenetworkornot', '128','$1','$1','$8', '129','10','$1','$8')
