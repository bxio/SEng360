#!/bin/bash
run_command="./faulty"
for x in "$@"
do
	run_command+=" \"$x\""
done
eval $run_command