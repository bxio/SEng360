q=../../../question_library/think_c/functions/

rm -rf $q/*
