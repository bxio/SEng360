product_family = 'code_activator'
question_type = 'input_output'
hotspot_declarations = {'$y1': 'float'}
display = r'''#include &lt;stdio.h>

int main(int argc, char* argv[])
{
	int r,i;
	double x;

	r = 1;
	x = 1.0;
	for (i = 0; i < 3; i++) {
		x = (x + r/x) / 2;
		printf("%4.3f\n",x);
	}

	return 0;
}
'''
argvs = r''''''
stdin = r''''''
stdout = r'''1.000
$y1
1.000
'''
