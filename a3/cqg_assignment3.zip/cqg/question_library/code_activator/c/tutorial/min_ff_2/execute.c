#include <stdlib.h>

int ca_argv_1;
#include <stdio.h>

int main(int argc, char* argv[])
{
ca_argv_1 = atoi(argv[argc-1+0]);
	int a,b;
	a = ca_argv_1;
	b = 7;
	if (a < b)
		printf("%d\n", a);
	else
		printf("%d\n", b);
	return 0;
}
