q=../../../question_library/think_c/functions

rm -rf $q/*

code_activator_generate.py compare_function.py $q
code_activator_generate.py swap_cbr.py $q
code_activator_generate.py swap_cbv.py $q
code_activator_generate.py swap_no_temp.py $q
code_activator_generate.py jason_quiz0.py $q
