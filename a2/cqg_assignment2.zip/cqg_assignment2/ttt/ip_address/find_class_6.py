tuples = ('find_class_6','whichnetworkclass', '121','$1','$1','$8')
