code_lib_path = '../question_library/'

question_list = [
	#(mark,	count,	[directories])
	# [10/5]
	(1,	5,	['find*']),
	# [5]
	(2,	5,	['add_at*']),
	# [5]
	(2,	5,	['bin_search_bull_*']),
	# [0/5]
	(2,	5,	['bin_search_io_forward_*'])
]
practice_mode = False
standalone = False
logged = True
log_dir = '../quiz_log/lab2'
