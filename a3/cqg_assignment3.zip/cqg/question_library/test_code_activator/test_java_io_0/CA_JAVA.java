public class CA_JAVA {
	public static int ca_argv_1 = 0;

}
