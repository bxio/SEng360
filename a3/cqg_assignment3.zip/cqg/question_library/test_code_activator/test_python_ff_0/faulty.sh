#!/bin/sh
python faulty.py $@