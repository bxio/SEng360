product_family = 'multiple_choice'
question_type = 'multiple_choice'

question_text = r'''Identify the name below that is not a syntactically correct identifier in the programming language C.'''
answers = ['a. ABC ', 'b. _52 ', 'c. for ', 'd. Int ']
correct_answer = 2
