product_family = 'multiple_choice'
question_type = 'multiple_choice'

question_text = r'''Identify the syntax errors, if any, in the following C program. 
<pre>
#include <stdio.h> 
int main() { printf("csc 111"); return 1; } 
</pre>'''
answers = ['a. newline character \\n is missing in the printf() call statement ', 'b. comments are missing ', 'c. main() returns 1 instead of 0  ', 'd. There are no syntax errors ']
correct_answer = 3
