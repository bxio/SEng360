forward = ['min_io_forward_']
for i in range(1,6):
	forward.append([i,5 - i,None])

tuple_list = [
	forward,
	['min_io_backward_',	[None,None,1],	[None,None,6]],
	['min_io_mixed_',	[None,2,None],	[3,None,1]],
	['min_io_open_',	[None,None,None]],
]
