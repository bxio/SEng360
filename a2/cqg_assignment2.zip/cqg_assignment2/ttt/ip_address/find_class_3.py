tuples = ('find_class_3','whichnetworkclass', '202','13','172','9')
