product_family = 'multiple_choice'
question_type = 'multiple_choice'

question_text = r'''What is the name of the function present in following syntactically correct
C Program?<br />
<pre>
#include &lt;stdio.h> 
#include &lt;stdlib.h> 
int main(void) {
	printf("Welcome to CSC111\n");
	printf("Knowledge is Power");
	return EXIT_SUCCESS; 
} /*main*/ 
</pre>'''
answers = ['a. stdio.h', 'b. main ', 'c. printf ', 'd. return ']
correct_answer = 1
