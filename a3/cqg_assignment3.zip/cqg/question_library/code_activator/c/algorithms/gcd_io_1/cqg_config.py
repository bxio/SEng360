product_family = 'code_activator'
question_type = 'input_output'
hotspot_declarations = {'$y4': 'string', '$y5': 'string', '$y6': 'string', '$y7': 'string', '$y0': 'string', '$y1': 'string', '$y2': 'string', '$y3': 'string'}
display = r'''#include &lt;stdio.h>

int gcd(int x,int y)
{
	while (x != y) {
		printf("%d %d\n",x,y);
		if (x < y)
			y = y-x;
		else
			x = x-y;
	}
	return x;
}
int main(int argc, char* argv[])
{
	int g;
	
	g = gcd(26,34);        

	return 0;
}
'''
argvs = r''''''
stdin = r''''''
stdout = r'''$y0
$y1
$y2
$y3
$y4
$y5
$y6
$y7
'''
