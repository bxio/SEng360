product_family = 'code_activator'
question_type = 'input_output'
hotspot_declarations = {'$y4': 'string', '$y0': 'string', '$y1': 'string', '$y2': 'string', '$y3': 'string'}
display = r'''#include &lt;stdio.h>

// Purpose: return the index of x in a[0..n-1]
// Preconditions:
//   n > 0 and a[0..n-1] dereferenceable
//   x occurs exactly once in a[0..n-1]
int find(int a[],int n,int x) {

void bubble_sort(int a[],int n)
{
	int i,j,x;

	for (i = 0; i < n-1; i++) {
		for (j = 0; j < n-i-1; j++) {
			if (a[j] > a[j+1]) {
				x = a[j]; a[j] = a[j+1]; a[j+1] = x;
				printf("%d\n",find(a,n,3));
			}
		}
	} 
}
int main(int argc, char* argv[])
{
	int a[] = {2,1,3};

	bubble_sort(a,3);        

	return 0;
}
'''
argvs = r''''''
stdin = r''''''
stdout = r'''$y0
$y1
$y2
$y3
$y4
'''
