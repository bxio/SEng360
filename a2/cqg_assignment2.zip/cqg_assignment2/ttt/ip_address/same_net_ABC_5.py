tuples = ('same_net_ABC_5','samenetworkornot', '192','168','0','9', '192','168','0','2')
