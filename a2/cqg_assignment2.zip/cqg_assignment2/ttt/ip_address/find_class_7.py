tuples = ('find_class_7','whichnetworkclass', '127','$1','$0','8')
