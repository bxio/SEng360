q=../../../../question_library/code_activator/tutorial/java

rm -rf $q/*

code_activator_generate.py min_be.py $q
code_activator_generate.py min_ff.py $q
code_activator_generate.py min_io.py $q
