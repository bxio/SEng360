product_family = 'code_activator'
question_type = 'find_the_failure'
hotspot_declarations = {'$x2': 'int'}
display = r'''#include &lt;stdio.h>

int main(int argc, char* argv[])
{
	int a,b;
	a = 1;
	b = $x2;
	// print the smaller of a and b
	if (a < b)
		printf("%d\n", a);
	else
		printf("%d\n", a);
	return 0;
}
'''
argvs = r''''''
stdin = r''''''
stdout = r''''''
