tuples = ('same_net_ABC_2','samenetworkornot', '127','1','1','8', '127','10','1','8')
