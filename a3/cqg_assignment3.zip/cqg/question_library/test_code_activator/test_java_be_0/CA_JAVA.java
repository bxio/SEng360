public class CA_JAVA {
	public static int ca_argv_1 = 0;
static int[] ca_targets = new int[1];
}
