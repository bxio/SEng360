import sys

ca_argv_1 = 0
import sys

ca_argv_1 = int(sys.argv[len(sys.argv)-1+0])
if sum < 6:
	print "hello"
