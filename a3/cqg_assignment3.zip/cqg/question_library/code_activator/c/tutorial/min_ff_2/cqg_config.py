product_family = 'code_activator'
question_type = 'find_the_failure'
hotspot_declarations = {'$x1': 'int'}
display = r'''#include &lt;stdio.h>

int main(int argc, char* argv[])
{
	int a,b;
	a = $x1;
	b = 7;
	// print the smaller of a and b
	if (a < b)
		printf("%d\n", a);
	else
		printf("%d\n", a);
	return 0;
}
'''
argvs = r''''''
stdin = r''''''
stdout = r''''''
