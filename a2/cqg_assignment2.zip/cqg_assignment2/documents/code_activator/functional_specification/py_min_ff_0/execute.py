#!/usr/bin/python
import sys

def min(a,b):
	if a < b:
		return a
	else:
		return b
	
pydoku_argv_1 = int(sys.argv[len(sys.argv)-1+0])
print min(1,pydoku_argv_1)
sys.exit(0)
