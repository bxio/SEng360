#!/bin/bash
run_command="./execute"
for x in "$@"
do
	run_command+=" \"$x\""
done
eval $run_command