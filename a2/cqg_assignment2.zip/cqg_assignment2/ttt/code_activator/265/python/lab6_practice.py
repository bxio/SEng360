code_lib_path = '../question_library'

question_list = [
#	(mark, 	count, [directories])
	(1,	4,	['list_multi_to_one_reference_io_*']),

#	(1,	4,	['list_slices_defaultUL_io_forward_*']),
	(1,	7,	['list_slices_defaultUL_io_backward_*']),

#	(1,	4,	['list_slices_outOfRange_io_forward_*']),
	(1,	7,	['list_slices_outOfRange_io_backward_*']),

#	(1,	4,	['list_slices_replace_io_forward_*']),
	(1,	8,	['list_slices_replace_io_mixed_backward_*']),

#	(1,	4,	['list_reference_semantics_io_forward_*']),
	(1,	4,	['list_reference_semantics_io_mixed_backward_*']),
]

practice_mode = True
standalone = False
logged = False
log_dir = ''
