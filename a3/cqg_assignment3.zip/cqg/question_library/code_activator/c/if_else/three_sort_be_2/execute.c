int ca_argv_1;
int ca_argv_2;
int ca_argv_3;
int ca_targets[1] = {0};
#include <stdio.h>

int main(int argc, char* argv[])
{
ca_argv_1 = atoi(argv[argc-3+0]);
ca_argv_2 = atoi(argv[argc-3+1]);
ca_argv_3 = atoi(argv[argc-3+2]);
	int a,b,c,x;

	a = ca_argv_1;
	b = ca_argv_2;
	c = ca_argv_3;

	if (a > b) {
		
		x = a; a = b; b = x;
	}
	if (b > c) {
		
		x = b; b = c; c = x;
	}
	if (a > b) {
		ca_targets[0] = 1;
		x = a; a = b; b = x;
	}

	printf("%d %d %d\n",a,b,c);
if (ca_targets[0])
	return 0;
else
	return 1;
	return 0;
}
