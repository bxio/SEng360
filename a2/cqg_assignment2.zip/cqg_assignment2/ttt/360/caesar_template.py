group_list = \
[
 [
  'caesar_',
  ['HELLOWORLD',3,[0,1,2]],
  ['ABCEDFG',5,[0,2]]
 ]
]
