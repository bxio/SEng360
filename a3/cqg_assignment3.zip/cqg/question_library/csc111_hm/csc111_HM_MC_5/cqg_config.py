product_family = 'multiple_choice'
question_type = 'multiple_choice'

question_text = r'''Identify logical errors, if any, in the following syntactically correct C
program that computes the area of a triangle (i.e., 1/2 of base times height). 
<pre>
#include &lt;stdio.h> 
#include &lt;stdlib.h> 
int main(void) { 
	float base = 10.8; 
	float height = 9.8; 
	float area = (base*height) % 2; 
	printf("(The area of this triangle is: %0.3f\n)", area); 
	return EXIT_SUCCESS; 
} /*main*/ 
</pre>'''
answers = ['a. remove parentheses () ', 'b. replace * with / ', 'c. replace % with / ', 'd. there are no logical errors in this program ']
correct_answer = 2
