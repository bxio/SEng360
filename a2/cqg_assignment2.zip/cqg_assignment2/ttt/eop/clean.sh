echo chapter2 -------------------------------------------
cd chapter2
. clean.sh
cd ..

echo chapter3 -------------------------------------------
cd chapter3
. clean.sh
cd ..

echo chapter7 -------------------------------------------
cd chapter7
. clean.sh
cd ..
