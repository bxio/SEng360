q=../../../question_library/eop/chapter2/

rm -rf $q/*
