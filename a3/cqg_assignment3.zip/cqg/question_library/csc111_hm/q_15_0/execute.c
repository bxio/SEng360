#include <stdio.h>
#include <stdlib.h>

void printText (void) { 
	printf ("UVic's 50th Anniversary\n"); 
} /*printText*/ 

void printNLines (int n) { 
	int k; 
	for (k=1; k<=n; k++); 
} /*printNLines*/ 

int main(int argc, char* argv[])
{
	printNLines(4); 
	printNLines(21); 
	return EXIT_SUCCESS; 
	return 0;
}
