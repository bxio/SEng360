# algorithms: coming soon

# control_flow: coming soon

echo functions -------------------------------------------
cd functions
. clean.sh
cd ..

# input_output: coming soon

echo pointers_arrays -------------------------------------------
cd pointers_arrays
. clean.sh
cd ..

echo strings -------------------------------------------
cd strings
. clean.sh
cd ..

# structures: coming soon

# types_operators_expressions: coming soon

echo warm_up -------------------------------------------
cd warm_up
. clean.sh
cd ..
