tuples = ('same_net_mask_3','samesubnetornot', '126','1','0','10', '126','127','0','1', '255','128','0','0')
