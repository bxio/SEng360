#!/bin/sh
./faulty $@