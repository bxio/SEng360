code_lib_path = '../code_library'

question_list = [
#	(mark, 	count, [directories])
	(1,	5,	['re_group_*']),
	(1,	5,	['re_date_*']),
	(1,	5,	['re_nonmatch_group_*']),
]

practice_mode = False
standalone = False
logged = True
log_dir = '../quiz8_log'
