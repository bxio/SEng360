#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
	printf("Welcome to CSC 111\n"); 
	printf("Knowledge is Power\n"); 
	printf("Develop a passion for learning.\n"); 
	printf("If you do, "); 
	printf("you will never cease to grow.\n"); 
	return EXIT_SUCCESS; 
	return 0;
}
