#!/bin/sh
python execute.py $@