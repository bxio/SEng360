#include <stdio.h>

int min(int a, int b) {
	if (a < b) {
		return a;
	} else {
		return b;
	}
}
int main(int argc, char* argv[])
{
	int a, b;
	scanf("%d", &a);
	scanf("%d", &b);
	printf("%d\n", min(a,b));
	return 0;
}
