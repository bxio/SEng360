tuples = ('ip_address_question_2','samesubnetornot','$x1','$x2','$x3','$x4','$y1','$y2','$y3','$y4','$z1','$z2','$z3','$z4')
