code_lib_path = '../question_library/'

question_list = [
#	(mark,	count,	[directories])
	(1,	2,	['strlen_base*']),
	(1,	2,	['strlen_*']),
	(1,	3,	['strlen_raw*']),

	(1,	2,	['strcpy_base*']),
	(1,	2,	['strcpy_*']),
	(1,	3,	['strcpy_raw*']),

	(1,	3,	['strcmp_*']),
	(1,	3,	['strcmp_code*']),
]

practice_mode = True
standalone = False
logged = False
log_dir = ''
