#include <stdio.h>

int gcd(int x,int y)
{
	while (x != y) {
		printf("%d %d\n",x,y);
		if (x < y)
			y = y-x;
		else
			x = x-y;
	}
	return x;
}
int main(int argc, char* argv[])
{
	int g;
	
	g = gcd(26,34);        

	return 0;
}
