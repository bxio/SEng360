#!/bin/sh
cd faulty
java Test $@