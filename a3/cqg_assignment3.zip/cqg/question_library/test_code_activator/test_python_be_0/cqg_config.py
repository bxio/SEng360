product_family = 'code_activator'
question_type = 'bullseye'
hotspot_declarations = {'$stdin': 'int', '$code': 'int', '$argvs': 'int'}
display = r'''import sys

code = $code
argvs = int(sys.argv[2])
tokens = sys.stdin.read().split()
stdin = int(tokens[1])
sum = code+argvs+stdin
if sum <= 6:
	ca_highlight
	print "%d\n" % sum
'''
argvs = r'''argvs: $argvs'''
stdin = r'''stdin: $stdin'''
stdout = r''''''
