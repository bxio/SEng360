q=../../../question_library/think_c/pointers_arrays/

rm -rf $q/*
