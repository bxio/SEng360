question_list = [
#	(mark, 	count, [directories])
	(1,	2,	['re_operators_concatenation_*']),
	(1,	2,	['re_operators_alternation_*']),
#	(1,	2,	['re_operators_kleene_*']),
	(1,	2,	['re_operators_all_A_*']),
	(1,	2,	['re_operators_substring_*']),
#	(1,	2,	['re_operators_closures_*']),
#	(1,	2,	['re_operators_list_*']),
	(1,	2,	['re_operators_dot_*']),
	(1,	2,	['re_operators_escapes_*']),
	(1,	2,	['re_operators_all_B_*']),
	(1,	6,	['re_list_forward_*']),
]

practice_mode = False
standalone = False
logged = True
log_dir = '../quiz8_log/'
