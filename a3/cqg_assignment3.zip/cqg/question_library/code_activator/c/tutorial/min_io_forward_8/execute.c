#include <stdlib.h>

#include <stdio.h>

int main(int argc, char* argv[])
{
	int a,b;
	a = 1;
	b = 3;
	if (a < b)
		printf("%d\n", a);
	else
		printf("%d\n", b);
	return 0;
}
