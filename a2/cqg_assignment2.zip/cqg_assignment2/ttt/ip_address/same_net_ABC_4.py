tuples = ('same_net_ABC_4','samenetworkornot', '192','168','0','9', '198','162','0','2')
