product_family = 'code_activator'
question_type = 'input_output'
hotspot_declarations = {'$s': 'ascii_string'}
display = r'''#include &lt;stdio.h>

int main(int argc, char* argv[])
{
	printf("$s\n");
	return 0;
}
'''
argvs = r''''''
stdin = r''''''
stdout = r'''hello world
'''
