product_family = 'multiple_choice'
question_type = 'multiple_choice'

question_text = r'''Which token must be added to make the following C program syntactically
correct?
<pre>
#include <stdio.h> 
#include <stdlib.h> 
int main(void) { 
	printf("Welcome to CSC111 \n") 
	printf("Knowledge is Power") 
	return EXIT_SUCCESS 
}'''
answers = ['a. Colon : ', 'b. Comma , ', 'c. semicolon ; ', 'd. /*main*/ ']
correct_answer = 2
