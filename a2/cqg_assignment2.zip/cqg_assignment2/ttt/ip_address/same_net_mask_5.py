tuples = ('same_net_mask_5','samesubnetornot', '172','16','0','1', '172','1','0','11', '255','255','0','0')
