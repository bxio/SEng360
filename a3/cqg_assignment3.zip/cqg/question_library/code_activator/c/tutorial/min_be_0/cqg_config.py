product_family = 'code_activator'
question_type = 'bullseye'
hotspot_declarations = {'$x2': 'int'}
display = r'''#include &lt;stdio.h>

int main(int argc, char* argv[])
{
	int a,b;
	a = 1;
	b = $x2;
	if (a < b) {
		ca_highlight
		printf("%d\n", a);
	} else {
		
		printf("%d\n", b);
	}
	return 0;
}
'''
argvs = r''''''
stdin = r''''''
stdout = r''''''
