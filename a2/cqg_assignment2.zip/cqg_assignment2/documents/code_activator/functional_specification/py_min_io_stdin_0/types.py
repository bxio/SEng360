game_type = 'Input/output'
parameter_types = {'argvs': {'$x0': 'int'}, 'code': {'$i1': 'int'}, 'stdout': {'$y0': 'int'}}
