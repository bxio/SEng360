#include <stdio.h>

int main(int argc, char* argv[])
{
	int a,b,c,x;

	a = 1;
	b = 7;
	c = 5;

	if (a > b) {
		x = a; a = b; b = x;
	}
	if (b > c) {
		x = b; b = c; c = x;
	}
	if (a > b) {
		x = a; a = b; b = x;
	}

	printf("%d %d %d\n",a,b,c);
	return 0;
}
