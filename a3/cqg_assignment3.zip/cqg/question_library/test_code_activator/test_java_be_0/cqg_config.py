product_family = 'code_activator'
question_type = 'bullseye'
hotspot_declarations = {'$stdin': 'int', '$code': 'int', '$argvs': 'int'}
display = r'''public class Test {
	public static void main(String[] args) {
		int argvs,stdin,code = $code,sum;
		argvs = Integer.parseInt(args[1]);
		java.util.Scanner sc = new java.util.Scanner(System.in);
		sc.next();
		stdin = sc.nextInt();
		sum = code+argvs+stdin;
		if (sum <= 6) {
			ca_highlight
			System.out.printf("%d\n", sum);
		}
	}
}'''
argvs = r'''argvs: $argvs'''
stdin = r'''stdin: $stdin'''
stdout = r''''''
