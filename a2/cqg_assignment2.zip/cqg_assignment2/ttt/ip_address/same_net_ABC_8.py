tuples = ('same_net_ABC_8','samenetworkornot', '172','$8','$8','$8', '10','$8','$8','$8')
