#include <stdio.h>

int x = 0;

void gaps(int x[],int n)
{
	int i=0, j=0;
	while (i < n) {
		if (j < x[i]) {
			printf("%d\n",j);
		} else {
			i++;
		}
		j++;
	}
}
int main(int argc, char* argv[])
{
	int a[] = {1,2};

	gaps(a,2);        

	return 0;
}
