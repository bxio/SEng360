q=../../../question_library/think_c/warm_up/

rm -rf $q/*
