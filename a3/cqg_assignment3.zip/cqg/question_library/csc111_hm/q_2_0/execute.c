#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
	int k; 
	for (k=1; k<=5; k++) { 
		printf("%d ", k); 
	} /*for*/ 
	return EXIT_SUCCESS; 
	return 0;
}
