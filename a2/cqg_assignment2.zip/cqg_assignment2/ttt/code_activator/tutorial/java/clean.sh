q=../../../../question_library/code_activator/tutorial/java

rm -rf $q/*
