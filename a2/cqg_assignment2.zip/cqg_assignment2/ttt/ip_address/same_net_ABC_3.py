tuples = ('same_net_ABC_3','samenetworkornot', '129','1','1','8', '129','10','1','8')
