#include <stdlib.h>

int ca_argv_1;
int ca_targets[1] = {0};
#include <stdio.h>

int main(int argc, char* argv[])
{
ca_argv_1 = atoi(argv[argc-1+0]);
	int a,b;
	a = 1;
	b = ca_argv_1;
	if (a < b) {
		ca_targets[0] = 1;
		printf("%d\n", a);
	} else {
		
		printf("%d\n", b);
	}
if (ca_targets[0])
	return 0;
else
	return 1;
	return 0;
}
