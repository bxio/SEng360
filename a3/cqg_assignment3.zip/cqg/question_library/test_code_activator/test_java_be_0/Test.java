public class Test {
	public static void main(String[] args) {
CA_JAVA.ca_argv_1 = Integer.parseInt(args[args.length-1+0]);
		int argvs,stdin,code = CA_JAVA.ca_argv_1,sum;
		argvs = Integer.parseInt(args[1]);
		java.util.Scanner sc = new java.util.Scanner(System.in);
		sc.next();
		stdin = sc.nextInt();
		sum = code+argvs+stdin;
		if (sum <= 6) {
			CA_JAVA.ca_targets[0] = 1;
			System.out.printf("%d\n", sum);
		}
if (CA_JAVA.ca_targets[0] > 0)
	System.exit(0);
else
	System.exit(1);
	}
}