product_family = 'code_activator'
question_type = 'input_output'
hotspot_declarations = {'$y4': 'string', '$y0': 'string', '$y1': 'string', '$y2': 'string', '$y3': 'string'}
display = r'''#include &lt;stdio.h>
#include &lt;stdlib.h>

int main(int argc, char* argv[])
{
	printf("Welcome to CSC 111\n"); 
	printf("Knowledge is Power\n"); 
	printf("Develop a passion for learning.\n"); 
	printf("If you do, "); 
	printf("you will never cease to grow.\n"); 
	return EXIT_SUCCESS; 
	return 0;
}
'''
argvs = r''''''
stdin = r''''''
stdout = r'''$y0
$y1
$y2
$y3
$y4
'''
