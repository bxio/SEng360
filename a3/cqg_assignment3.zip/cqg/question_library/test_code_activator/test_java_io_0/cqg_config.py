product_family = 'code_activator'
question_type = 'input_output'
hotspot_declarations = {'$stdout': 'int', '$stdin': 'int', '$code': 'int', '$argvs': 'int'}
display = r'''public class Test {
	public static void main(String[] args) {
		int argvs,stdin,code = $code,sum;
		argvs = Integer.parseInt(args[1]);
		java.util.Scanner sc = new java.util.Scanner(System.in);
		sc.next();
		stdin = sc.nextInt();
		sum = code+argvs+stdin;
		System.out.printf("stdout: %d\n", sum);
	}
}'''
argvs = r'''argvs: $argvs'''
stdin = r'''stdin: $stdin'''
stdout = r'''stdout: $stdout
'''
