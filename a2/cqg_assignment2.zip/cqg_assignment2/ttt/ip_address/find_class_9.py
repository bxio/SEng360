tuples = ('find_class_9','whichnetworkclass', '212','$131','1','9')
