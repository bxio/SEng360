product_family = 'multiple_choice'
question_type = 'multiple_choice'

question_text = r'''Question text'''
answers = ['incorrect', 'correct', 'incorrect']
correct_answer = 1
