import sys

ca_argv_1 = 0
import sys

ca_argv_1 = int(sys.argv[len(sys.argv)-1+0])
code = ca_argv_1
argvs = int(sys.argv[2])
tokens = sys.stdin.read().split()
stdin = int(tokens[1])
sum = code+argvs+stdin
print "stdout: %d\n" % sum
