product_family = 'code_activator'
question_type = 'input_output'
hotspot_declarations = {'$y0': 'string', '$y1': 'string', '$y2': 'string', '$y3': 'string'}
display = r'''#include &lt;stdio.h>
#include &lt;stdlib.h>

void printText (void) { 
	printf ("UVic's 50th Anniversary\n"); 
} /*printText*/ 

void printNLines (int n) { 
	int k; 
	for (k=1; k<=n; k++); 
} /*printNLines*/ 

int main(int argc, char* argv[])
{
	printNLines(4); 
	printNLines(21); 
	return EXIT_SUCCESS; 
	return 0;
}
'''
argvs = r''''''
stdin = r''''''
stdout = r'''$y0
$y1
$y2
$y3
'''
