code_lib_path = '../code_library'

question_list = [
#	(mark, 	count, [directories])
	(1,	2,	['re_operators_concatenation_*']),
	(1,	2,	['re_operators_alternation_*']),
	(1,	2,	['re_operators_kleene_*']),
	(1,	2,	['re_operators_all_A_*']),
	(1,	2,	['re_operators_substring_*']),
	(1,	2,	['re_operators_closures_*']),
	(1,	2,	['re_operators_list_*']),
	(1,	2,	['re_operators_dot_*']),
	(1,	2,	['re_operators_escapes_*']),
	(1,	2,	['re_operators_all_B_*']),
]

practice_mode = True
standalone = False
logged = False
log_dir = ''
