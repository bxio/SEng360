#include <stdio.h>
#include <stdlib.h>

void f5(void) { printf("desire "); } 
void f7(void) { printf("to "); } 
void f1(void) { printf("learn something useful\n"); } 
void f3(void) { printf("always "); } 

int main(int argc, char* argv[])
{
	f3(); f5(); f7(); f1(); 
	return EXIT_SUCCESS; 
	return 0;
}
