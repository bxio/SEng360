tuples = ('ip_address_question_1','whichnetworkclass','$x1','$x2','$x3','$x4')
