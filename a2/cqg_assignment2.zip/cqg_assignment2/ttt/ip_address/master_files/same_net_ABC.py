# 6 forward, 4 mixed
tuples = ('same_net_ABC_0','samenetworkornot', '172','8','8','8', '10','8','8','8')
tuples = ('same_net_ABC_1','samenetworkornot', '8','8','8','8', '10','8','8','8')
tuples = ('same_net_ABC_2','samenetworkornot', '127','1','1','8', '127','10','1','8')
tuples = ('same_net_ABC_3','samenetworkornot', '129','1','1','8', '129','10','1','8')
tuples = ('same_net_ABC_4','samenetworkornot', '192','168','0','9', '198','162','0','2')
tuples = ('same_net_ABC_5','samenetworkornot', '192','168','0','9', '192','168','0','2')

tuples = ('same_net_ABC_6','samenetworkornot', '192','$168','0','9', '192','$168','0','2')
tuples = ('same_net_ABC_7','samenetworkornot', '128','$1','$1','$8', '129','10','$1','$8')
tuples = ('same_net_ABC_8','samenetworkornot', '172','$8','$8','$8', '10','$8','$8','$8')
tuples = ('same_net_ABC_9','samenetworkornot', '8','$8','$8','$8', '10','$8','$8','$8')
