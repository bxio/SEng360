tuples = ('same_net_ABC_9','samenetworkornot', '8','$8','$8','$8', '10','$8','$8','$8')
