code_lib_path = '../code_library'

question_list = [
#	(mark, 	count, [directories])
	(1,	7,	['re_group_*']),
	(1,	8,	['re_date_*']),
]

practice_mode = True
standalone = False
logged = False
log_dir = ''
