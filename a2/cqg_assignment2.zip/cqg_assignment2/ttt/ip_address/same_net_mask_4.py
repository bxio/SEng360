tuples = ('same_net_mask_4','samesubnetornot', '126','1','0','10', '127','126','0','1', '255','128','0','0')
