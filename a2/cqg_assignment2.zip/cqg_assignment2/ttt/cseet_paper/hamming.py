tuples = \
[
	['fill_checkbits_',
		['0101010',0,[1,2,4,8]],
	],
]
