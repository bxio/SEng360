public class Test {
	public static void main(String[] args) {
CA_JAVA.ca_argv_1 = Integer.parseInt(args[args.length-1+0]);
		int argvs,stdin,code = CA_JAVA.ca_argv_1,sum;
		argvs = Integer.parseInt(args[1]);
		java.util.Scanner sc = new java.util.Scanner(System.in);
		sc.next();
		stdin = sc.nextInt();
		sum = code+argvs+stdin;
		if (sum < 6)
			System.out.printf("hello");
	}
}