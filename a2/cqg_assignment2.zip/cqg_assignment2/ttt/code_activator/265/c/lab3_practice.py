code_lib_path = '../question_library/'

question_list = [
#	(mark,	count,	[directories])
	(1,	3,	['shift_point_*']),
	# following 3 entries for marked quiz only
	#(1,	1,	['delete_[0-2]']),
	#(1,	1,	['delete_[3-5]']),
	#(1,	1,	['delete_[6-8]']),
	(1,	3,	['add_front_cbr_*']),
	(1,	3,	['add_front_cbv_*']),
	(1,	3,	['add_back_cbr_*']),
]

practice_mode = True
standalone = False
logged = False
log_dir = ''
