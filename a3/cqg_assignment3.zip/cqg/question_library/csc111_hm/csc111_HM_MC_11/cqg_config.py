product_family = 'multiple_choice'
question_type = 'multiple_choice'

question_text = r'''Which pair of tokens indicates the beginning and end of a compound statement in the programming language C?'''
answers = ['a. { } ', 'b. < > ', 'c. begin end ', 'd. ( ) ']
correct_answer = 0
