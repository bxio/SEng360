product_family = 'multiple_choice'
question_type = 'multiple_choice'

question_text = r'''What are the steps in an application development cycle?'''
answers = ['a. Build<br />Edit<br />Compile <br />Run<br />', 'b. Edit<br />Build<br />Compile<br />Run<br />', 'c. Edit<br />Compile<br />Run<br />Build<br />', 'd. Edit<br />Compile<br />Build<br />Run<br />']
correct_answer = 3
